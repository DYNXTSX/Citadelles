package application;

public class Application {
    public static void main(String args[]){
        Jeu jeu = new Jeu(1);
        jeu.jouer();

    }
}
