package extension.complete;

import modele.Quartier;

public class Capitole extends Quartier {
    public Capitole(){
        super("Capitole","MERVEILLE",5," la fin de la partie, marquez 3 points suppl´ementaires si vous avez au moins 3 quartiers du même type (couleur) dans votre cité. Vous ne pouvez utiliser l’effet du capitole qu’une seule fois. ");
    }
}
