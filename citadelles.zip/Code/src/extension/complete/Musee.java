package extension.complete;
import modele.Quartier;

public class Musee extends Quartier {
    public Musee(){
        super("Musee","MERVEILLE",4,"Une fois par tour, vous pouvez placer une carte de votre main, face cachée, sous le Musée. A la fin de la partie, marquez 1 point supplémentaire par carte sous le Mus´ee. Si le Mus´ee est d´eplac´e d’une cit´e `a une autre, il conserve toutes les cartes qui ´etaient dessous. Si le Mus´ee est d´etruit, les cartes sont défaussées, face cachée, sous la pioche.");
    }
}