package extension.complete;

import modele.Quartier;

public class Grande_Muraille extends Quartier {
    public Grande_Muraille(){
        super("Grande_Muraille","MERVEILLE",6,"Les personnages de rang 8 doivent payer 1 pièce d’or supplémentaire pour affecter un quartier de votre cité. La Grande Muraille n’affecte pas le coût de construction des quartiers de la cité du Diplomate quand il utilise son pouvoir.");
    }
}
