package extension.complete;
import modele.Quartier;

public class Theatre extends Quartier {
    public Theatre(){
        super("Theatre","MERVEILLE",6," A la fin de la phase de s´election, vous pouvez échanger votre carte Personnage face cachée avec celle d’un autre joueur. Le propriétaire du Théatre choisit avec qui il fait l'échange, sans avoir vu aucune des cartes des autres joueurs. Les cartes échangées en peuvent être révélées aux autres joueurs avant d'être appelées. Dans une partie à 2 ou 3 joueurs, le propriétaire du Théâtre choisit le carte Personnage parmi les deux cartes du joueur choisi pour l'échange, sans les regarder. ");
    }
}